export function sayHi(name){
    console.log("hi",name)
}

export function doUpper(str){
    console.log(str.toUpperCase())
}

export default function multiply(n1, n2){
    console.log(n1*n2)
}

export function divide(n1, n2){
    console.log(n1/n2)
}