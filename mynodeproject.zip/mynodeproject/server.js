import express from 'express'

let app=express()

app.get('/',(request,response)=>{
    return response.send("hi");
});

app.get("/kyaboltatu",(req,res)=>{
    return res.send("Lai bhari")
})

app.listen(5005,()=>{

console.log("listen")
})