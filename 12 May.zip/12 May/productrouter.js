import { Router } from "express";
let productrouter = Router()

export default productrouter

let products=[]

let body = {
    "productId" :1,
    "productName" : "AAA",
    "costPerUnit": 30,
    "units": 2}

productrouter.post("/add",(req,res)=>{
    products.push(body)
    res.send("Product added successfully")
})

productrouter.get("/getInfo",(req,res)=>{
    let pid = req.query.id

    for(let i=0; i<=products.length; i++){

        if(pid==products[i].productId){
            res.send(products[i])
        }
    }
    
})

productrouter.get("/all",(req,res)=>{
    res.send(products)
})

productrouter.put("/changecost",(req,res)=>{
    let pid = req.query.productid
    let pcost = req.query.productcost

    for(let i=0; i<=products.length; i++){

        if(pid==products[i].productId){
            products[i].costPerUnit=pcost
        }
    }
})