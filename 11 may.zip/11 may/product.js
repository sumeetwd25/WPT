export  class product
{
    constructor(name,cost)
    {
        this.pname=name
        this.cost=cost
    }

     show()
    {
        console.log(this.pname,this.cost)
    }

    static show2(obj)
    {
        
        console.log(obj.pname,obj.cost)
    }

}


