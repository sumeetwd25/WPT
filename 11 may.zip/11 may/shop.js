import {product} from "./product.js"

 let obj=new product("saban",20)


product.show2(obj)